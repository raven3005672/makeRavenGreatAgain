// import * as React from "react";

// const Button = () => <button>App 2 Button change test demo</button>;

// export default Button;
import * as React from "react";
import { useState } from "react";
// import React, { useState } from 'react';
// import './index.css';

const RemoteButton = () => {
  const [ value, setValue ] = useState(0);

  return <div className='xxx'>
    <span>老子真是艹了currentValue={value}</span>
    <button onClick={() => {
      setValue((x) => x+1)
    }}>remote-button</button>
  </div>
}

export default RemoteButton;