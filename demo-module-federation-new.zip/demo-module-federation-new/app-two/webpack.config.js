const path = require('path')
const HtmlWebpackPlugin = require('html-webpack-plugin')
const ModuleFederationPlugin = require('webpack/lib/container/ModuleFederationPlugin')

module.exports = {
    entry: './src/index.jsx',
    output: {
        filename: 'two.js',
        path: path.resolve(__dirname, 'dist'),
    },
    mode: 'development',
    resolve: {
        extensions: [".js", ".jsx"],
    },
    module: {
        rules: [
            {
                test: /\.css$/i,
                use: ['style-loader', 'css-loader']
            },
            {
                test: /\.jsx$/i,
                exclude: /node_modules/,
                use: {
                    loader: 'babel-loader',
                    options: {
                        presets: ['@babel/preset-env', '@babel/preset-react']
                    }
                }
            }
        ]
    },
    devServer: {
        port: 8089,
    },
    plugins: [
        new HtmlWebpackPlugin({
            template: './dist/index.html',
            title: 'app-two'
        }),
        new ModuleFederationPlugin({
            name: "appTwo",
            // library: { type: 'var', name: 'appTwo' },  // 必须？这里的name作为umd的name
            filename: "remoteEntry.js",
            exposes: {
                "./Button": "./src/Button"
            },
            //   shared: ['react', 'react-dom']
            shared: {
              react: { singleton: true, eager: true },
              "react-dom": { singleton: true, eager: true }
            }
        }),
    ]
}