const path = require('path')
const HtmlWebpackPlugin = require('html-webpack-plugin')
const ModuleFederationPlugin = require('webpack/lib/container/ModuleFederationPlugin')
const deps = require('./package.json').dependencies;

module.exports = {
    entry: './src/index.jsx',
    output: {
        filename: '[name].js',
        path: path.resolve(__dirname, 'dist'),
        clean: true
    },
    mode: 'development',
    resolve: {
        extensions: [".js", ".jsx"],
    },
    module: {
        rules: [
            {
                test: /\.css$/i,
                use: ['style-loader', 'css-loader']
            },
            {
                test: /\.jsx$/i,
                exclude: /node_modules/,
                use: {
                    loader: 'babel-loader',
                    options: {
                        presets: ['@babel/preset-env', '@babel/preset-react']
                    }
                }
            }
        ]
    },
    devServer: {
        port: 8088,
    },
    plugins: [
        new HtmlWebpackPlugin({
            title: 'app-one',
            template: './dist/index.html'
        }),
        new ModuleFederationPlugin({
            name: "appOne",
            remoteType: 'var',
            remotes: {
              appTwo: 'appTwo',
              // appTwo: "http://localhost:8089/remoteEntry.js"
                // appTwo: "appTwo@http://localhost:8089/remoteEntry.js",
                // mfRemote: "mfRemote@http://localhost:9000/remoteFilename.js",
            },
            //   shared: ['react', 'react-dom']
            shared: {
              ...deps,
              "react": { singleton: true, eager: true, requiredVersion: deps["react"] },
              "react-dom": { singleton: true, eager: true, requiredVersion: deps["react-dom"] }
            }
        }),
    ]
}