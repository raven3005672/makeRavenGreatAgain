import React from "react";
const RemoteButton = React.lazy(() => import("appTwo/Button"));
// const RemoteButton2 = React.lazy(() => import('mfRemote/remoteButton'));

const App = () => (
  <div>
    <h1>App one</h1>
    {/* 因为是远程加载的模块，需要使用 Suspense 添加 fallback */}
    <React.Suspense fallback="Loading Button">
      <RemoteButton />
    </React.Suspense>
    <div>22222</div>
    {/* <React.Suspense fallback="Loading Button22222">
      <RemoteButton2 />
    </React.Suspense> */}
  </div>
);

export default App;
